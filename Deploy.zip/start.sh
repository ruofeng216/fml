#!/bin/bash

# python path
opt= export PATH=/root/anaconda2/bin:$PATH

#qpidscan
opt= export LD_LIBRARY_PATH=/Sumscope/qpid-scan/qpid_scan_centos6.5/:/Sumscope/qpid-scan/qpid_scan_centos6.5_filter/:$LD_LIBRARY_PATH

#qt
opt= export LD_LIBRARY_PATH=/usr/local/lib64/:$LD_LIBRARY_PATH
opt= export QTDIR=/usr/local/Qt-5.7.0
opt= export export PATH=$QTDIR/bin:$PATH


opt= cd /Sumscope

PIDS=`ps -ef |grep redis |grep -v grep | awk '{print $2}'`
if [ "$PIDS" == "" ]; then
    if [ -f "/var/run/redis_6379.pid" ]; then
        rm -rf /var/run/redis_6379.pid
        service redis start
    fi
fi

opt= service tomcat stop
opt= service tomcat start
opt= qpidd -q
opt= qpidd -d
opt= echo "kill services..."
opt= ps -ef | grep Login | grep -v grep | cut -c 9-15 | xargs kill -s 9
opt= ps -ef | grep MiddleWareMonitorServer/main.py | grep -v grep | cut -c 9-15 | xargs kill -s 9
opt= ps -ef | grep MiddleWareFilter | grep -v grep | cut -c 9-15 | xargs kill -s 9
opt= ps -ef | grep MiddleWareAlert/monitor/monitoralert.py | grep -v grep | cut -c 9-15 | xargs kill -s 9
opt= ps -ef | grep BaseController | grep -v grep | cut -c 9-15 | xargs kill -s 9
opt= ps -ef | grep qpid_scan | grep -v grep | cut -c 9-15 | xargs kill -s 9

opt= echo "start service..."
opt= mkdir Monitor
opt= cd Monitor
opt= ln -s /Deploy/MonitorServices.zip /Sumscope/Monitor/MonitorServices.zip
opt= unzip -o MonitorServices.zip
opt= cd MonitorServices
opt= chmod +x qpidinit.sh
opt= ./qpidinit.sh
opt= python setup.py install

opt= python configinit.py

#qpidscan
opt= export LD_LIBRARY_PATH=/Sumscope/qpid-scan/qpid_scan_centos6.5/:/Sumscope/qpid-scan/qpid_scan_centos6.5_filter/:$LD_LIBRARY_PATH
opt= cd /Sumscope/qpid-scan/qpid_scan_centos6.5/
opt= nohup ./qpid_scan >/dev/null 2>log &
opt= cd /Sumscope/qpid-scan/qpid_scan_centos6.5_filter/
opt= nohup ./qpid_scan >/dev/null 2>log &
if [ ! -f "/Sumscope/qpid-scan/qpid_scan_centos6.5/all_exchanges.txt" ]; then
  opt= echo "Please wait for 2 minute...."
  opt= sleep 120
fi
if [ ! -f "/Sumscope/qpid-scan/qpid_scan_centos6.5/all_queues.txt" ]; then
  opt= echo "Please wait for 2 minute...."
  opt= sleep 120
fi
if [ ! -f "/Sumscope/qpid-scan/qpid_scan_centos6.5_filter/all_exchanges.txt" ]; then
  opt= echo "Please wait for 2 minute...."
  opt= sleep 120
fi
if [ ! -f "/Sumscope/qpid-scan/qpid_scan_centos6.5_filter/all_queues.txt" ]; then
  opt= echo "Please wait for 2 minute...."
  opt= sleep 120
fi
opt= cd /Sumscope/Monitor/MonitorServices/
opt= nohup python BaseController >/dev/null 2>log &
opt= nohup python Login >/dev/null 2>log &
opt= nohup python MiddleWareMonitorServer/main.py >/dev/null 2>log &
opt= nohup python MiddleWareFilter -t tp.newbond >/dev/null 2>log &
opt= nohup python MiddleWareAlert/monitor/monitoralert.py >/dev/null 2>log &
opt= echo "ok"

opt= cd /Sumscope
opt= mkdir MiddleWare
opt= cd MiddleWare
opt= ln -s /Deploy/MiddleWare.zip /Sumscope/MiddleWare/MiddleWare.zip
opt= unzip -o MiddleWare.zip
opt= cp -r  MiddleWare /Sumscope/tomcat/apache-tomcat-7.0.70/webapps
opt= echo "web ok!" 

