#!/bin/bash

rm -rf /etc/redis/6379.conf
rm -rf /etc/init.d/redis

opt= yum install -y glibc-static libstdc++-static gcc gcc-c++ wget unzip libX11 libX11-devel fontconfig perl openssl xcb* mysql-devel libGL libGL-devel libxcb libxcb-devel libXrender libXrender-devel xcb-util-wm xcb-util-wm-devel xcb-util xcb-util-devel xcb-util-image xcb-util-image-devel xcb-util-keysyms xcb-util-keysyms-devel
opt= mkdir /Sumscope
opt= cd /Deploy
opt= chmod +x redis
opt= chmod +x redis.sh
opt= chmod +x Anaconda2-4.1.0-Linux-x86_64.sh
opt= chmod +x anaconda.sh
opt= chmod +x qt.sh
opt= chmod +x gcc.sh
opt= chmod +x qpidscan.sh
opt= chmod +x start.sh
opt= chmod +x pythonpkg.sh
opt= chmod +x qpid.sh
opt= chmod +x tomcat.sh

opt= cd /Deploy
opt= echo -------------start to install redis   --------
opt= echo -------------      please wait ...    --------
opt= sleep 10
opt= sudo ./redis.sh
opt= echo -----------------redis ok------------------
opt= echo -------------start to install anaconda--------
opt= echo -------------      please wait ...    --------
opt= sleep 10
opt= cd /Deploy
opt= sudo ./anaconda.sh
opt= echo -----------------anaconda ok---------------------
opt= echo -------------start to install gcc   --------
opt= echo -------------      please wait ...  --------
opt= sleep 10
opt= cd /Deploy
opt= sudo ./gcc.sh
opt= echo -----------------gcc ok--------------------
opt= echo -------------start to install qt    --------
opt= echo -------------      please wait ...  --------
opt= sleep 10
opt= cd /Deploy
opt= ./qt.sh
opt= echo -----------------qt ok---------------------
opt= echo -------------start to install pythonpkg    --------
opt= echo -------------      please wait ...    --------
opt= sleep 10
opt= cd /Deploy
opt= ./pythonpkg.sh
opt= echo ----------------python pkg ok--------------
opt= echo -------------start to install qpidscan    --------
opt= echo -------------      please wait ...        --------
opt= sleep 10
opt= cd /Deploy
opt= sudo ./qpidscan.sh
opt= echo -----------------qpidscan ok---------------
opt= echo -------------start to install qpid    --------
opt= echo -------------      please wait ...    --------
opt= sleep 10
opt= cd /Deploy
opt= sudo ./qpid.sh
opt= echo -----------------qpid ok-------------------
opt= echo -------------start to install tomcat    --------
opt= echo -------------      please wait ...    --------
opt= sleep 10
opt= cd /Deploy
opt= sudo ./tomcat.sh
opt= echo -----------------tomcat ok-----------------

opt= echo -------------modify iptables--------------------
opt= service iptables stop
opt= echo -----------------iptables ok-------------------

opt= echo -------------modify timezone--------------------
opt= rm -rf /etc/localtime
opt= ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
opt= hwclock --systohc
opt= echo -----------------timezone ok-------------------
opt= echo -------------      please wait to restart computer...    --------
opt= shutdown -r 1

