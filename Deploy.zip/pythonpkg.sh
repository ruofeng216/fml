#!/bin/bash
opt= export PATH=/root/anaconda2/bin:$PATH
opt= pip install pip --upgrade
opt= pip install redis
opt= pip install redis --upgrade
opt= cd /Sumscope
opt= mkdir pyqt5
opt= cd pyqt5
if [ -d "./sip-4.18.1" ]; then
  opt= rm -rf sip-4.18.1
fi
opt= ln -s /Deploy/sip-4.18.1.tar.gz /Sumscope/pyqt5/sip-4.18.1.tar.gz
opt= tar -xvf sip-4.18.1.tar.gz
opt= cd sip-4.18.1
opt= echo ----------start to install sip-4.18.1-------------
opt= export LD_LIBRARY_PATH=/usr/local/lib64/:$LD_LIBRARY_PATH
opt= export QTDIR=/usr/local/Qt-5.7.0
opt= export PATH=$QTDIR/bin:$PATH
opt= python configure.py --use-qmake
opt= echo -----------wait for make sip...------------------------------
opt= qmake
opt= echo -----------wait for install sip...----------------------
opt= make install
opt= echo -----------start to install pyqt5----------------
opt= export LD_LIBRARY_PATH=/usr/local/lib64/:$LD_LIBRARY_PATH
opt= export QTDIR=/usr/local/Qt-5.7.0
opt= export PATH=$QTDIR/bin:$PATH
opt= cd /Sumscope/pyqt5
opt= ln -s /Deploy/PyQt5_gpl-5.7.tar.gz /Sumscope/pyqt5/PyQt5_gpl-5.7.tar.gz
opt= tar -xvf PyQt5_gpl-5.7.tar.gz
opt= cd PyQt5_gpl-5.7
opt= python configure.py
opt= echo -----------wait for make pyqt5...------------------------
opt= make
opt= echo -----------wait for install pyqt5...---------------------
opt= make install

opt= export PATH=/root/anaconda2/bin:$PATH
opt= pip install argparse
opt= pip install qpid-python
opt= pip install qpid-tools

