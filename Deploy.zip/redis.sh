#!/bin/bash

opt= ps -ef | grep redis | grep -v grep | cut -c 9-15 | xargs -0 kill
echo "----------------clean last run file---------------"
if [ -f "/var/run/redis_6379.pid" ]; then
    rm -rf /var/run/redis_6379.pid
fi

opt= echo "-----------------start to redis pre--------------------------------------"
opt= cd /Sumscope
opt= mkdir tcl 
opt= cd tcl 
opt= ln -s /Deploy/tcl8.6.5-src.tar.gz /Sumscope/tcl/tcl8.6.5-src.tar.gz
opt= tar -xf tcl8.6.5-src.tar.gz --strip-components=1 
export SRCDIR=pwd &&cd unix &&./configure --prefix=/usr \ 
--mandir=/usr/share/man \ 
$([ $(uname -m) = x86_64 ] && echo --enable-64bit) && 
make &&

sed -e "s#$SRCDIR/unix#/usr/lib#" \ 
-e "s#$SRCDIR#/usr/include#" \ 
-i tclConfig.sh &&

sed -e "s#$SRCDIR/unix/pkgs/tdbc1.0.4#/usr/lib/tdbc1.0.4#" \ 
-e "s#$SRCDIR/pkgs/tdbc1.0.4/generic#/usr/include#" \ 
-e "s#$SRCDIR/pkgs/tdbc1.0.4/library#/usr/lib/tcl8.6#" \ 
-e "s#$SRCDIR/pkgs/tdbc1.0.4#/usr/include#" \ 
-i pkgs/tdbc1.0.4/tdbcConfig.sh &&

sed -e "s#$SRCDIR/unix/pkgs/itcl4.0.4#/usr/lib/itcl4.0.4#" \ 
-e "s#$SRCDIR/pkgs/itcl4.0.4/generic#/usr/include#" \ 
-e "s#$SRCDIR/pkgs/itcl4.0.4#/usr/include#" \ 
-i pkgs/itcl4.0.4/itclConfig.sh &&

unset SRCDIR 
opt= make test 
opt= make install  &&
make install-private-headers && 
ln -v -sf tclsh8.6 /usr/bin/tclsh && 
chmod -v 755 /usr/lib/libtcl8.6.so

opt= echo "----------------------------start to redis now---------------------------------------"
opt= cd /Sumscope
opt= mkdir redis
opt= cd redis
opt= ln -s /Deploy/redis-3.2.0.tar.gz /Sumscope/redis/redis-3.2.0.tar.gz 
opt= tar -xvf redis-3.2.0.tar.gz 
opt= cd redis-3.2.0
opt= make MALLOC=libc
opt= make test 
opt= make prefix=/usr/local install
opt= mkdir /etc/redis && mkdir /redis &&mkdir /redis/log &&mkdir /redis/db
opt= ln -s /Deploy/redis /etc/init.d/redis
opt= ln -s /Deploy/6379.conf /etc/redis/6379.conf
opt= sysctl vm.overcommit_memory=1
opt= chkconfig --add redis 
opt= chkconfig redis on

opt= service redis start
opt= ps -ef | grep redis






















