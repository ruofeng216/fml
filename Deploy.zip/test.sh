#!/bin/bash
opt= cd /Sumscope
opt= mkdir MiddleWare
opt= cd MiddleWare
opt= ln -s /Deploy/MiddleWare.zip /Sumscope/MiddleWare/MiddleWare.zip
opt= unzip -o MiddleWare.zip
opt= cp -r  MiddleWare /Sumscope/tomcat/apache-tomcat-7.0.70/webapps
opt= echo "web ok!"

