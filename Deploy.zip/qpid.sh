#!/bin/bash
#

opt= cd /Sumscope
opt= mkdir qpid
opt= cd qpid
opt= ln -s /Deploy/qpid-cpp-1.35.0.tar.gz /Sumscope/qpid/qpid-cpp-1.35.0.tar.gz
opt= tar -xvf qpid-cpp-1.35.0.tar.gz
opt= cd qpid-cpp-1.35.0

opt= yum install -y boost libuuid pkgconfig xqilla xerces-c nss nspr  libibverbs librdmacm ruby swig cmake boost-devel libuuid-devel help2man doxygen graphviz e2fsprogs-devel cyrus-sasl-devel nss-devel nspr-devel xqilla-devel xerces-c-devel ruby-devel libdb-cxx-devel libaio-devel openais

opt= export PYTHONPATH=/root/anaconda2/bin:$PYTHONPATH
opt= yum install -y python-qpid qpid-cpp-server qpid-tools 

opt= mkdir build
opt= cd build
opt= cmake ..
opt= make all
opt= make install

opt= export PATH=/root/anaconda2/bin:$PATH
opt= qpid-config --max-queue-size=104857600
opt= qpid-config --max-queue-count=100

opt= qpidd -d



