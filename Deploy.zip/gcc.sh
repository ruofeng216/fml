#!/bin/bash

opt= cd /Sumscope
opt= mkdir gcc
opt= cd gcc
if [ -d "./gcc-6.2.0" ]; then
  opt= rm -rf gcc-6.2.0
fi
opt= ln -s /Deploy/gcc-6.2.0.tar.bz2 /Sumscope/gcc/gcc-6.2.0.tar.bz2
opt= tar   -jxvf gcc-6.2.0.tar.bz2
opt= cd gcc-6.2.0
opt= ./contrib/download_prerequisites
opt= mkdir build
opt= cd build
opt= sudo ../configure --enable-checking=release --enable-languages=c,c++ --disable-multilib
opt= sudo make -j4
opt= sudo make install
opt= /usr/sbin/update-alternatives --install  /usr/bin/gcc gcc /usr/local/bin/x86_64-pc-linux-gnu-gcc-6.2.0 100


