#!/bin/bash
if [ -d "/root/anaconda2/" ]; then
  opt= rm -rf /root/anaconda2/
fi
opt= cd /Sumscope
opt= mkdir anaconda
opt= cd anaconda
opt= ln -s /Deploy/Anaconda2-4.1.0-Linux-x86_64.sh /Sumscope/anaconda/Anaconda2-4.1.0-Linux-x86_64.sh
opt= ./Anaconda2-4.1.0-Linux-x86_64.sh
opt= export PATH=/root/anaconda2/bin:$PATH
opt= echo OK----------------
