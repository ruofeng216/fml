#!/bin/bash

opt= cd /Sumscope
if [ -d "./qt" ]; then
  opt= rm -rf qt
fi
opt= mkdir qt
opt= cd qt
opt= ln -s /Deploy/qt-everywhere-opensource-src-5.7.0.tar.gz /Sumscope/qt/qt-everywhere-opensource-src-5.7.0.tar.gz
opt= tar -zxvf qt-everywhere-opensource-src-5.7.0.tar.gz
opt= cd qt-everywhere-opensource-src-5.7.0 
opt= export LD_LIBRARY_PATH=/usr/local/lib64/:$LD_LIBRARY_PATH
opt= ./configure -nomake examples -nomake tests -skip purchasing -skip canvas3d -skip virtualkeyboard -skip qtgamepad
opt= gmake -j4
opt= gmake install
opt= export QTDIR=/usr/local/Qt-5.7.0
opt= export PATH=$QTDIR/bin:$PATH
opt= echo -----------qt OK--------------

