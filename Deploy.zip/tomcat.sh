#!/bin/bash

opt= cd /Sumscope
opt= mkdir tomcat
opt= cd tomcat
opt= ln -s /Deploy/jdk-8u101-linux-x64.tar.gz  /Sumscope/tomcat/jdk-8u101-linux-x64.tar.gz
opt= tar -xvf jdk-8u101-linux-x64.tar.gz
opt= export JAVA_HOME=/Sumscope/tomcat/jdk1.8.0_101
opt= export JRE_HOME=/usr/java/jdk1.8.0_101/jre
opt= export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib
opt= export PATH=$PATH:$JAVA_HOME/bin
opt= ln -s /Deploy/apache-tomcat-7.0.70.tar.gz  /Sumscope/tomcat/apache-tomcat-7.0.70.tar.gz
opt= tar -xvf apache-tomcat-7.0.70.tar.gz
opt= cd apache-tomcat-7.0.70
opt= ln -s /Deploy/tomcat /etc/init.d/tomcat
opt= chmod 755 /etc/init.d/tomcat
opt= chkconfig --add tomcat
opt= service tomcat start
opt= ps -ef | grep tomcat

