#!/bin/bash

opt= cd /Sumscope
opt= mkdir qpid-scan
opt= cd qpid-scan
if [ -d "./qpid_scan_centos6.5" ]; then
  opt= rm -rf qpid_scan_centos6.5
fi
if [ -d "./qpid_scan_centos6.5_filter" ]; then
  opt= rm -rf qpid_scan_centos6.5_filter
fi
opt= ln -s /Deploy/qpid_scan_centos6.5.tar.gz /Sumscope/qpid-scan/qpid_scan_centos6.5.tar.gz
opt= tar -xvf qpid_scan_centos6.5.tar.gz
opt= cd qpid_scan_centos6.5
opt= chmod +x qpid_scan
opt= export LD_LIBRARY_PATH=$PWD:$LD_LIBRARY_PATH
opt= cd ..
opt= mkdir qpid_scan_centos6.5_filter
opt= cp -r ./qpid_scan_centos6.5/* qpid_scan_centos6.5_filter
opt= cd qpid_scan_centos6.5_filter
opt= export LD_LIBRARY_PATH=$PWD:$LD_LIBRARY_PATH

